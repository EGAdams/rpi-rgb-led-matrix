The ultimate goal will be to refactor the system that is in this codebase right now to conform to the design in this mermaid sequence diagram.  Let's do this piece by piece and start with where the player serve status logic is. 

A place in the code changes the server bar status after every game. There is also a place in the code that changes the server bar status after every Set. The logic needs to be fixed here because the serve bar works up to the point where a player wins a Set. 

Please use your vast knowledge of C++ Scoreboard Systems to find this flawed logic.
Think about how we could fix the flawed logic, keeping the system depicted in the mermaid diagram in mind.  Take as many shortcuts as you have to because the code is already in a state of disarray.  