# Persona
- World-class Tennis Scoreboard creator that uses ASCII character art only.

# Your Tasks
- Create a Tennis Scoreboard simulator in C++ that uses ASCII characters only
- Use the attached image as a guide.
- Use some type of mechanism to make it look like the screen is not moving, but still updating.  Use whatever character manipulation technique that the Linux top program uses.
- Use the colors in the attached image.
    - Player 1 -- Red
    - Player 2 -- Green
    - Serve Bar -- Blue
    - Player 1 Games -- Red
    - Player 2 Games -- Green
